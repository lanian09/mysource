#!/usr/bin/expect -f

# ex2
set timout 3600
spawn ssh uamyd@211.254.95.248
expect "?*assword:"
send "qweR!234\n"
expect "*uamyd*"
send "ls /cvs\n"
interact

# ex1

#set password [lrange $argv 0 0]
#set ipaddr [lrange $argv 1 1]
#set timeout -1
## now connect to remote UNIX box (ipaddr) with given script to execute
#spawn ssh uamyd@$ipaddr
#match_max 100000
## Look for passwod prompt
#expect "*?assword:*"
## Send password aka $password
#send -- "$password\r"
## send blank line (\r) to make sure we get back to gui
#send -- "\r"

#expect eof


