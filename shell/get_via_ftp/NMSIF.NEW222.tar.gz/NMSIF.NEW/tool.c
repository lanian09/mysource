#include <nmsif_proto.h>
#include <nmsif.h>

char		*int2dot (int);
struct tm	*now ();

HoldFList	hold_list[FILE_NUM_5MIN+FILE_NUM_HOUR];

extern	ListenInfo	ne_info;
extern	SFM_sfdb	*sfdb;

extern	MYSQL	*conn;
extern	char	traceBuf[];
extern	int		trcFlag, trcLogFlag;

int get_alm_code (int atype)
{
    switch (atype)
	{
		case SFM_ALM_TYPE_CPU_USAGE				:	return ALMCODE_SFM_CPU_USAGE;
		case SFM_ALM_TYPE_MEMORY_USAGE			:	return ALMCODE_SFM_MEMORY_USAGE;
		case SFM_ALM_TYPE_DISK_USAGE			:	return ALMCODE_SFM_DISK_USAGE;
		case SFM_ALM_TYPE_LAN					:	return ALMCODE_SFM_LAN;
		case SFM_ALM_TYPE_PROC					:	return ALMCODE_SFM_PROCESS;
		case SFM_ALM_TYPE_LINK					:	return ALMCODE_SFM_LINK;
		case SFM_ALM_TYPE_MP_HW					:	return ALMCODE_SFM_HPUX_HW;
	//	case SFM_ALM_TYPE_CONN_SERVER			:	return ALMCODE_SFM_SERVER_CONN;
		case SFM_ALM_TYPE_CALL_INFO				:	return ALMCODE_SFM_CALL_INFO;
		case SFM_ALM_TYPE_DUP_STS				:	return ALMCODE_SFM_DUPLICATION;
		case SFM_ALM_TYPE_DUP_HEARTBEAT			:	return ALMCODE_SFM_HEARTBEAT;
		case SFM_ALM_TYPE_DUP_OOS				:	return ALMCODE_SFM_OOS;
		case SFM_ALM_TYPE_SUCC_RATE				:	return ALMCODE_SFM_SUCCESS_RATE;
		case SFM_ALM_TYPE_SESS_LOAD				:	return ALMCODE_SFM_SESS_LOAD;
		case SFM_ALM_TYPE_DBCON_STST			:	return ALMCODE_SFM_RMT_DB_STS;
		case SFM_ALM_TYPE_RMT_LAN				:	return ALMCODE_SFM_RMT_LAN;
		case SFM_ALM_TYPE_OPT_LAN				:	return ALMCODE_SFM_OPT_LAN;
		case SFM_ALM_TYPE_HWNTP					:	return ALMCODE_SFM_HWNTP;
		//case SFM_ALM_TYPE_PD_CPU_USAGE			:	return ALMCODE_SFM_PD_CPU_USAGE;
		//case SFM_ALM_TYPE_PD_MEMORY_USAGE		:	return ALMCODE_SFM_PD_MEMORY_USAGE;
		//case SFM_ALM_TYPE_PD_FAN_STS			:	return ALMCODE_SFM_PD_FAN_USAGE;
		//case SFM_ALM_TYPE_PD_GIGA_LAN			:	return ALMCODE_SFM_PD_GIGA_USAGE;
		case SFM_ALM_TYPE_TAP_CPU_USAGE			:	return ALMCODE_SFM_TAP_CPU_USAGE;
		case SFM_ALM_TYPE_TAP_MEMORY_USAGE		:	return ALMCODE_SFM_TAP_MEMORY_USAGE;
		case SFM_ALM_TYPE_TAP_FAN_STS			:	return ALMCODE_SFM_TAP_FAN_USAGE;
		case SFM_ALM_TYPE_TAP_PORT_STS			:	return ALMCODE_SFM_TAP_PORT_STS;
		case SFM_ALM_TYPE_RSRC_LOAD				:	return ALMCODE_SFM_RSRC_LOAD;
		case SFM_ALM_TYPE_QUEUE_LOAD			:	return ALMCODE_SFM_QUEUE_LOAD;
		case SFM_ALM_TYPE_NMSIF_CONNECT			:	return ALMCODE_NMS_CONNECT;
		case SFM_ALM_TYPE_DUAL_ACT				:	return ALMCODE_SFM_DUAL_ACT;
		case SFM_ALM_TYPE_DUAL_STD				:	return ALMCODE_SFM_DUAL_STD;
		case SFM_ALM_TYPE_DUAL_STS_QRY_TIME_OUT	:	return ALMCODE_SFM_DUAL_STS_QRY_TIME_OUT;
		case SFM_ALM_TYPE_SCE_CPU				:	return ALMCODE_SFM_SCE_CPU_USAGE;
		case SFM_ALM_TYPE_SCE_MEM				:	return ALMCODE_SFM_SCE_MEM_USAGE;
		case SFM_ALM_TYPE_SCE_DISK				:	return ALMCODE_SFM_SCE_DISK_USAGE;
		case SFM_ALM_TYPE_SCE_PWR				:	return ALMCODE_SFM_SCE_PWR_USAGE;
		case SFM_ALM_TYPE_SCE_FAN				:	return ALMCODE_SFM_SCE_FAN_USAGE;
		case SFM_ALM_TYPE_SCE_TEMP				:	return ALMCODE_SFM_SCE_TEMP_STS;
		//case SFM_ALM_TYPE_SCE_VOLT			:	return ALMCODE_SFM_SCE_UNKNOWN;
		case SFM_ALM_TYPE_SCE_VOLT				:	return ALMCODE_SFM_UNKNOWN;
		case SFM_ALM_TYPE_SCE_PORT_MGMT			:	return ALMCODE_SFM_SCE_PORT_USAGE;
		case SFM_ALM_TYPE_SCE_PORT_LINK			:	return ALMCODE_SFM_SCE_PORT_USAGE;
		//case SFM_ALM_TYPE_SCE_RDR				:	return ALMCODE_SFM_SCE_UNKNOWN;
		case SFM_ALM_TYPE_SCE_RDR				:	return ALMCODE_SFM_UNKNOWN;
		case SFM_ALM_TYPE_SCE_RDR_CONN			:	return ALMCODE_SFM_SCE_RDR_CONN_STS;
		case SFM_ALM_TYPE_SCE_STATUS			:	return ALMCODE_SFM_SCE_SYS_STS;
		case SFM_ALM_TYPE_L2_CPU				:	return ALMCODE_SFM_L2SW_CPU_USAGE;
		case SFM_ALM_TYPE_L2_MEM				:	return ALMCODE_SFM_L2SW_MEMORY_USAGE;
		case SFM_ALM_TYPE_L2_LAN				:	return ALMCODE_SFM_L2SW_LAN_STS;
		case SFM_ALM_TYPE_CPS_OVER				:	return ALMCODE_SFM_CPS_OVER_INFO;
		case SFM_ALM_TYPE_PROCESS_SAMD			:	return ALMCODE_SFM_PROCESS_SAMD;
		case SFM_ALM_TYPE_PROCESS_IXPC			:	return ALMCODE_SFM_PROCESS_IXPC;
		case SFM_ALM_TYPE_PROCESS_FIMD			:	return ALMCODE_SFM_PROCESS_FIMD;
		case SFM_ALM_TYPE_PROCESS_COND			:	return ALMCODE_SFM_PROCESS_COND;
		case SFM_ALM_TYPE_PROCESS_STMD			:	return ALMCODE_SFM_PROCESS_STMD;
		case SFM_ALM_TYPE_PROCESS_MMCD			:	return ALMCODE_SFM_PROCESS_MMCD;
		case SFM_ALM_TYPE_PROCESS_MCDM			:	return ALMCODE_SFM_PROCESS_MCMD;
		case SFM_ALM_TYPE_PROCESS_NMSIF			:	return ALMCODE_SFM_PROCESS_NMSIF;
		case SFM_ALM_TYPE_PROCESS_CDELAY		:	return ALMCODE_SFM_PROCESS_CDELAY;
		case SFM_ALM_TYPE_PROCESS_HAMON			:	return ALMCODE_SFM_PROCESS_HAMON;
		case SFM_ALM_TYPE_PROCESS_MMCR			:	return ALMCODE_SFM_PROCESS_MMCR;
		case SFM_ALM_TYPE_PROCESS_RDRANA		:	return ALMCODE_SFM_PROCESS_RDRANA;
		case SFM_ALM_TYPE_PROCESS_RLEG			:	return ALMCODE_SFM_PROCESS_RLEG;
		case SFM_ALM_TYPE_PROCESS_SMPP			:	return ALMCODE_SFM_PROCESS_SMPP;
		case SFM_ALM_TYPE_PROCESS_PANA			:	return ALMCODE_SFM_PROCESS_PANA;
		case SFM_ALM_TYPE_PROCESS_RANA			:	return ALMCODE_SFM_PROCESS_RANA;
		case SFM_ALM_TYPE_PROCESS_RDRCAPD		:	return ALMCODE_SFM_PROCESS_RDRCAPD;
		case SFM_ALM_TYPE_PROCESS_CAPD			:	return ALMCODE_SFM_PROCESS_CAPD;
		case SFM_ALM_TYPE_HW_MIRROR				:	return ALMCODE_SFM_MIRROR_PORT;
		
        //default									:	return 0;
        default									:	return ALMCODE_SFM_UNKNOWN;
    }
} /* End of get_alm_code () */

/*
	by sjjeon 
	alarm level�� ���� alarm code�� �޶�����.
	nmsif�� class ���� 6(minor clear), 7(major clear)
	8 (critical clear) ��. 
	alarm code �� �߰����� ���� �����ش�.
	minor (+100), major (+200), critical (+300)
 */
#define ALM_MINOR_CLEAR			6
#define ALM_MAJOR_CLEAR			7
#define ALM_CRITICAL_CLEAR		8

int get_alm_code_ex (int atype, int almClass)
{
	int almCode, levelVal=0;

	switch(almClass){
		case SFM_ALM_MINOR:
		case ALM_MINOR_CLEAR:
        	levelVal = ALMCODE_STS_MINOR;   // 100
			break;
		case SFM_ALM_MAJOR:
		case ALM_MAJOR_CLEAR:
        	levelVal = ALMCODE_STS_MAJOR;   // 200
			break;
		case SFM_ALM_CRITICAL:
		case ALM_CRITICAL_CLEAR:
        	levelVal = ALMCODE_STS_CRITICAL; // 300
			break;
		default:
			break;
	}

    switch (atype)
	{
		case SFM_ALM_TYPE_CPU_USAGE				:	almCode = ALMCODE_SFM_CPU_USAGE; break;
		case SFM_ALM_TYPE_MEMORY_USAGE			:	almCode = ALMCODE_SFM_MEMORY_USAGE;	break;
		case SFM_ALM_TYPE_DISK_USAGE			:	almCode = ALMCODE_SFM_DISK_USAGE; break;
		case SFM_ALM_TYPE_LAN					:	almCode = ALMCODE_SFM_LAN; break;
		case SFM_ALM_TYPE_PROC					:	almCode = ALMCODE_SFM_PROCESS; break;
		case SFM_ALM_TYPE_LINK					:	almCode = ALMCODE_SFM_LINK; break;
		case SFM_ALM_TYPE_MP_HW					:	almCode = ALMCODE_SFM_HPUX_HW; break;
	//	case SFM_ALM_TYPE_CONN_SERVER			:	almCode = ALMCODE_SFM_SERVER_CONN; break;
		case SFM_ALM_TYPE_CALL_INFO				:	almCode = ALMCODE_SFM_CALL_INFO; break;
		case SFM_ALM_TYPE_DUP_STS				:	almCode = ALMCODE_SFM_DUPLICATION; break;
		case SFM_ALM_TYPE_DUP_HEARTBEAT			:	almCode = ALMCODE_SFM_HEARTBEAT; break;
		case SFM_ALM_TYPE_DUP_OOS				:	almCode = ALMCODE_SFM_OOS; break;
		case SFM_ALM_TYPE_SUCC_RATE				:	almCode = ALMCODE_SFM_SUCCESS_RATE; break;
		case SFM_ALM_TYPE_SESS_LOAD				:	almCode = ALMCODE_SFM_SESS_LOAD; break;
		case SFM_ALM_TYPE_DBCON_STST			:	almCode = ALMCODE_SFM_RMT_DB_STS; break;
		case SFM_ALM_TYPE_RMT_LAN				:	almCode = ALMCODE_SFM_RMT_LAN; break;
		case SFM_ALM_TYPE_OPT_LAN				:	almCode = ALMCODE_SFM_OPT_LAN; break;
		case SFM_ALM_TYPE_HWNTP					:	almCode = ALMCODE_SFM_HWNTP; break;
		//case SFM_ALM_TYPE_PD_CPU_USAGE		:	almCode = ALMCODE_SFM_PD_CPU_USAGE; break;
		//case SFM_ALM_TYPE_PD_MEMORY_USAGE		:	almCode = ALMCODE_SFM_PD_MEMORY_USAGE; break;
		//case SFM_ALM_TYPE_PD_FAN_STS			:	almCode = ALMCODE_SFM_PD_FAN_USAGE; break;
		//case SFM_ALM_TYPE_PD_GIGA_LAN			:	almCode = ALMCODE_SFM_PD_GIGA_USAGE;
		case SFM_ALM_TYPE_TAP_CPU_USAGE			:	almCode = ALMCODE_SFM_TAP_CPU_USAGE; break;
		case SFM_ALM_TYPE_TAP_MEMORY_USAGE		:	almCode = ALMCODE_SFM_TAP_MEMORY_USAGE; break;
		case SFM_ALM_TYPE_TAP_FAN_STS			:	almCode = ALMCODE_SFM_TAP_FAN_USAGE; break;
		case SFM_ALM_TYPE_TAP_PORT_STS			:	almCode = ALMCODE_SFM_TAP_PORT_STS; break;
		case SFM_ALM_TYPE_RSRC_LOAD				:	almCode = ALMCODE_SFM_RSRC_LOAD; break;
		case SFM_ALM_TYPE_QUEUE_LOAD			:	almCode = ALMCODE_SFM_QUEUE_LOAD; break;
		//case SFM_ALM_TYPE_NMSIF_CONNECT:			almCode = ALMCODE_NMS_CONNECT; break;
		case SFM_ALM_TYPE_NMSIF_CONNECT:			return 	ALMCODE_NMS_CONNECT; // NMS CONNECTION ALARM�� ���μ����� ���� ���� �ʴ´�.
		case SFM_ALM_TYPE_DUAL_ACT				:	almCode = ALMCODE_SFM_DUAL_ACT; break;
		case SFM_ALM_TYPE_DUAL_STD				:	almCode = ALMCODE_SFM_DUAL_STD; break;
		case SFM_ALM_TYPE_DUAL_STS_QRY_TIME_OUT	:	almCode = ALMCODE_SFM_DUAL_STS_QRY_TIME_OUT; break;
		case SFM_ALM_TYPE_SCE_CPU				:	almCode = ALMCODE_SFM_SCE_CPU_USAGE; break;
		case SFM_ALM_TYPE_SCE_MEM				:	almCode = ALMCODE_SFM_SCE_MEM_USAGE; break;
		case SFM_ALM_TYPE_SCE_DISK				:	almCode = ALMCODE_SFM_SCE_DISK_USAGE; break;
		case SFM_ALM_TYPE_SCE_PWR				:	almCode = ALMCODE_SFM_SCE_PWR_USAGE; break;
		case SFM_ALM_TYPE_SCE_FAN				:	almCode = ALMCODE_SFM_SCE_FAN_USAGE; break;
		case SFM_ALM_TYPE_SCE_TEMP				:	almCode = ALMCODE_SFM_SCE_TEMP_STS; break;
		//case SFM_ALM_TYPE_SCE_VOLT			:	almCode = ALMCODE_SFM_SCE_UNKNOWN; break;
		case SFM_ALM_TYPE_SCE_VOLT				:	almCode = ALMCODE_SFM_UNKNOWN; break;
		case SFM_ALM_TYPE_SCE_PORT_MGMT			:	almCode = ALMCODE_SFM_SCE_PORT_USAGE; break;break;
		case SFM_ALM_TYPE_SCE_PORT_LINK			:	almCode = ALMCODE_SFM_SCE_PORT_USAGE; break;
		//case SFM_ALM_TYPE_SCE_RDR				:	almCode = ALMCODE_SFM_SCE_UNKNOWN; break;
		case SFM_ALM_TYPE_SCE_RDR				:	almCode = ALMCODE_SFM_UNKNOWN; break;
		case SFM_ALM_TYPE_SCE_RDR_CONN			:	almCode = ALMCODE_SFM_SCE_RDR_CONN_STS; break;
		case SFM_ALM_TYPE_SCE_STATUS			:	almCode = ALMCODE_SFM_SCE_SYS_STS; break;
		case SFM_ALM_TYPE_L2_CPU				:	almCode = ALMCODE_SFM_L2SW_CPU_USAGE; break;
		case SFM_ALM_TYPE_L2_MEM				:	almCode = ALMCODE_SFM_L2SW_MEMORY_USAGE; break;
		case SFM_ALM_TYPE_L2_LAN				:	almCode = ALMCODE_SFM_L2SW_LAN_STS; break;
		case SFM_ALM_TYPE_CPS_OVER				:	almCode = ALMCODE_SFM_CPS_OVER_INFO; break;
		case SFM_ALM_TYPE_PROCESS_SAMD			:	almCode = ALMCODE_SFM_PROCESS_SAMD; break;
		case SFM_ALM_TYPE_PROCESS_IXPC			:	almCode = ALMCODE_SFM_PROCESS_IXPC; break;
		case SFM_ALM_TYPE_PROCESS_FIMD			:	almCode = ALMCODE_SFM_PROCESS_FIMD; break;
		case SFM_ALM_TYPE_PROCESS_COND			:	almCode = ALMCODE_SFM_PROCESS_COND; break;
		case SFM_ALM_TYPE_PROCESS_STMD			:	almCode = ALMCODE_SFM_PROCESS_STMD; break;
		case SFM_ALM_TYPE_PROCESS_MMCD			:	almCode = ALMCODE_SFM_PROCESS_MMCD; break;
		case SFM_ALM_TYPE_PROCESS_MCDM			:	almCode = ALMCODE_SFM_PROCESS_MCMD; break;
		case SFM_ALM_TYPE_PROCESS_NMSIF			:	almCode = ALMCODE_SFM_PROCESS_NMSIF; break;
		case SFM_ALM_TYPE_PROCESS_CDELAY		:	almCode = ALMCODE_SFM_PROCESS_CDELAY; break;
		case SFM_ALM_TYPE_PROCESS_HAMON			:	almCode = ALMCODE_SFM_PROCESS_HAMON; break;
		case SFM_ALM_TYPE_PROCESS_MMCR			:	almCode = ALMCODE_SFM_PROCESS_MMCR; break;
		case SFM_ALM_TYPE_PROCESS_RDRANA		:	almCode = ALMCODE_SFM_PROCESS_RDRANA; break;
		case SFM_ALM_TYPE_PROCESS_RLEG			:	almCode = ALMCODE_SFM_PROCESS_RLEG; break;
		case SFM_ALM_TYPE_PROCESS_SMPP			:	almCode = ALMCODE_SFM_PROCESS_SMPP; break;
		case SFM_ALM_TYPE_PROCESS_PANA			:	almCode = ALMCODE_SFM_PROCESS_PANA; break;
		case SFM_ALM_TYPE_PROCESS_RANA			:	almCode = ALMCODE_SFM_PROCESS_RANA; break;
		case SFM_ALM_TYPE_PROCESS_RDRCAPD		:	almCode = ALMCODE_SFM_PROCESS_RDRCAPD; break;
		case SFM_ALM_TYPE_PROCESS_CAPD			:	almCode = ALMCODE_SFM_PROCESS_CAPD; break;
		case SFM_ALM_TYPE_HW_MIRROR				:	almCode = ALMCODE_SFM_MIRROR_PORT; break;
		case SFM_ALM_TYPE_SCE_USER				:	almCode = ALMCODE_SFM_SCE_USER_USAGE; break;
		case SFM_ALM_TYPE_LEG_SESSION			:	almCode = ALMCODE_SFM_LEG_SESSION_USAGE; break;
		case SFM_ALM_TYPE_SCM_FAULTED			:	almCode = ALMCODE_SFM_SCM_FAULTED; break;
		case SFM_ALM_TYPE_LOGON_SUCCESS_RATE    :   almCode = ALMCODE_SFM_LOGON_SUCCESS_RATE; break;

        //default									:	return 0; break;
        default									:	return ALMCODE_SFM_UNKNOWN;
    }

	almCode += levelVal;
	return almCode;
	
} /* End of get_alm_code_ex () */

/*
   modified by sjjeon
	aclass�� level�� 6,7,8 �߰��Ѵ�. 
	6 : minor clear
	7 : major clear
	8 : critical clear
 */
get_alm_class (int aclass)
{
	switch (aclass) {
		case 8 : return 5; 		
		case 7 : return 5;
		case 6 : return 5;
		case 5 : return 5;
		case 3 : return 1;
		case 2 : return 2;
		case 1 : return 3;
		default : return 0;
	}

} /* End of get_alm_class () */

char *get_supple_info (char *node, int type, char *rsc)
{
        int             blen=0;
        static char     resbuf[1024];

        memset (resbuf, 0, 1024);

        strcpy (resbuf, node);
        blen = strlen (resbuf);

        if (type == SFM_ALM_TYPE_CPU_USAGE)
                sprintf (&resbuf[blen], ", %s (%s)", "CPU LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_MEMORY_USAGE)
                sprintf (&resbuf[blen], ", %s (%s)", "MEMORY LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_DISK_USAGE)
                sprintf (&resbuf[blen], ", %s (%s)", "DISK LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_LAN)
                sprintf (&resbuf[blen], ", %s (%s)", "MANAGEMENT NETWORK LINK ALARM", rsc);
        else if (type == SFM_ALM_TYPE_PROC)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM", rsc);
        else if (type == SFM_ALM_TYPE_MP_HW)
                sprintf (&resbuf[blen], ", %s (%s)", "DSC HW ALARM", rsc);
        else if (type == SFM_ALM_TYPE_CALL_INFO)
                sprintf (&resbuf[blen], ", %s (%s)", "CALL INFO ALARM", rsc);
        else if (type == SFM_ALM_TYPE_DUP_HEARTBEAT)
                sprintf (&resbuf[blen], ", %s (%s)", "DUPLICATION HEARTBEAT ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SUCC_RATE)
                sprintf (&resbuf[blen], ", %s (%s)", "SUCCESS RATE ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SESS_LOAD)
                sprintf (&resbuf[blen], ", %s (%s)", "SESSION LOAD ALARM", rsc);
		else if (type == SFM_ALM_TYPE_DBCON_STST)
                sprintf (&resbuf[blen], ", %s (%s)", "UAWAP DB CONNECTION STATUS ALARM", rsc);
        else if (type == SFM_ALM_TYPE_RMT_LAN)
                sprintf (&resbuf[blen], ", %s (%s)", "REMOTE NETWORK LINK ALARM", rsc);
        else if (type == SFM_ALM_TYPE_OPT_LAN)
                sprintf (&resbuf[blen], ", %s (%s)", "MIRRORING PORT ALARM", rsc);
        else if (type == SFM_ALM_TYPE_HWNTP)
                sprintf (&resbuf[blen], ", %s (%s)", "NETWORK TIME PROTOCOL ALARM", rsc);
        //else if (type == SFM_ALM_TYPE_PD_CPU_USAGE)
                //sprintf (&resbuf[blen], ", %s (%s)", "PROBING DEVICE CPU USAGE ALARM", rsc);
        else if (type == SFM_ALM_TYPE_TAP_CPU_USAGE)
                sprintf (&resbuf[blen], ", %s (%s)", "TAP CPU USAGE ALARM", rsc);
        //else if (type == SFM_ALM_TYPE_PD_MEMORY_USAGE)
                //sprintf (&resbuf[blen], ", %s (%s)", "PROBING DEVICE MEMORY USAGE ALARM", rsc);
        else if (type == SFM_ALM_TYPE_TAP_MEMORY_USAGE)
                sprintf (&resbuf[blen], ", %s (%s)", "TAP MEMORY USAGE ALARM", rsc);
        //else if (type == SFM_ALM_TYPE_PD_FAN_STS)
                //sprintf (&resbuf[blen], ", %s (%s)", "PROBING DEVICE FAN ALARM", rsc);
        else if (type == SFM_ALM_TYPE_TAP_FAN_STS)
                sprintf (&resbuf[blen], ", %s (%s)", "TAP FAN ALARM", rsc);
        //else if (type == SFM_ALM_TYPE_PD_GIGA_LAN)
                //sprintf (&resbuf[blen], ", %s (%s)", "PROBING DEVICE NETWORK ALARM", rsc);
        else if (type == SFM_ALM_TYPE_TAP_PORT_STS)
                sprintf (&resbuf[blen], ", %s (%s)", "TAP NETWORK LINK ALARM", rsc);
        else if (type == SFM_ALM_TYPE_RSRC_LOAD)
                sprintf (&resbuf[blen], ", %s (%s)", "RESOURCE LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_QUEUE_LOAD)
                sprintf (&resbuf[blen], ", %s (%s)", "QUEUE LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_NMSIF_CONNECT)
                sprintf (&resbuf[blen], ", %s (%s)", "NMSIF STATUS ALARM", rsc);
        else if (type == SFM_ALM_TYPE_DUAL_ACT)
                sprintf (&resbuf[blen], ", %s (%s)", "DUPLICATION STATUS DUAL ACTIVE ALARM", rsc);
        else if (type == SFM_ALM_TYPE_DUAL_STD)
                sprintf (&resbuf[blen], ", %s (%s)", "DUPLICATION STATUS DUAL STANDBY ALARM", rsc);
        else if (type == SFM_ALM_TYPE_DUAL_STS_QRY_TIME_OUT)
                sprintf (&resbuf[blen], ", %s (%s)", "DUAL STATUS QUERY TIME OUT ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_CPU)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE CPU LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_MEM)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE MEMORY LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_DISK)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE DISK LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_PWR)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE POWER ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_FAN)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE FAN ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_TEMP)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE TEMPERATURE ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_VOLT)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE EXCESS VOLTAGE ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_PORT_MGMT)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE MGMT LINK ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_PORT_LINK)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE LINK ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_RDR)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE RDR STATUS ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_RDR_CONN)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE RDR CONNECTION ALARM", rsc);
        else if (type == SFM_ALM_TYPE_SCE_STATUS)
                sprintf (&resbuf[blen], ", %s (%s)", "SCE STATUS ALARM", rsc);
        else if (type == SFM_ALM_TYPE_L2_CPU)
                sprintf (&resbuf[blen], ", %s (%s)", "L2 SWITCH CPU LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_L2_MEM)
                sprintf (&resbuf[blen], ", %s (%s)", "L2 SWITCH MEMORY LOAD ALARM", rsc);
        else if (type == SFM_ALM_TYPE_L2_LAN)
                sprintf (&resbuf[blen], ", %s (%s)", "L2 SWITCH LINK ALARM", rsc);
        else if (type == SFM_ALM_TYPE_CPS_OVER)
                sprintf (&resbuf[blen], ", %s (%s)", "SCM CPS OVER ALARM", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_SAMD)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(SAMD)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_IXPC)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(IXPC)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_FIMD)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(FIMD)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_COND)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(COND)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_STMD)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(STMD)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_MMCD)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(MMCD)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_MCDM)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(MCDM)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_NMSIF)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(NMSIF)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_CDELAY)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(CDELAY)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_HAMON)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(HAMON)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_MMCR)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(MMCR)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_RDRANA)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(RDRANA)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_RLEG)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(RLEG)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_SMPP)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(SMPP)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_PANA)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(PANA)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_RANA)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(RANA)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_RDRCAPD)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(RDRCAPD)", rsc);
        else if (type == SFM_ALM_TYPE_PROCESS_CAPD)
                sprintf (&resbuf[blen], ", %s (%s)", "SW PROCESS ALARM(CAPD)", rsc);
        else if (type == SFM_ALM_TYPE_HW_MIRROR)
                sprintf (&resbuf[blen], ", %s (%s)", "SCM H/W MIRROR LINK ALARM", rsc);
		else if (type == SFM_ALM_TYPE_LOGON_SUCCESS_RATE)
                sprintf (&resbuf[blen], ", %s", rsc);
        else
        	sprintf (&resbuf[blen], ", UNKNOWN ALARM (%s)", rsc);

        return resbuf;

} /* End of get_supple_info () */

char *get_oidtime_with_para(StatQueryInfo *qry)
{
	int         i,j;
	static char tm_oid[1024];
	memset(tm_oid, 0x00, sizeof(tm_oid));

	//time  e.g) "2011-02-27 12:45:00" @qry->stime
	//retur e.g) "20110227124500"

	i = j = 0;
	//year
	tm_oid[i++] = qry->stime[j++];
	tm_oid[i++] = qry->stime[j++];
	tm_oid[i++] = qry->stime[j++];
	tm_oid[i++] = qry->stime[j++];

	//month
	j++;
	tm_oid[i++] = qry->stime[j++];
	tm_oid[i++] = qry->stime[j++];

	//date
	j++;
	tm_oid[i++] = qry->stime[j++];
	tm_oid[i++] = qry->stime[j++];

	if( STAT_PERIOD_HOUR == qry->period || STAT_PERIOD_5MIN == qry->period ){
		j++;
		tm_oid[i++] = qry->stime[j++];
		tm_oid[i++] = qry->stime[j++];
		if( STAT_PERIOD_5MIN == qry->period ){
			j++;
			tm_oid[i++] = qry->stime[j++];
			tm_oid[i++] = qry->stime[j++];
		}
	}
	tm_oid[i] = 0x00;

	return tm_oid;
}

char *get_oidtime (int prd)
{
	static char	tm_oid[1024];
	struct tm	*n_time;

	n_time = (struct tm *)now ();

	memset(tm_oid, 0x00, sizeof(tm_oid));

	if (prd == STAT_PERIOD_5MIN)
		sprintf (tm_oid, "%04d%02d%02d%02d%02d", n_time->tm_year+1900, n_time->tm_mon+1, n_time->tm_mday, n_time->tm_hour, n_time->tm_min);
	else if (prd == STAT_PERIOD_HOUR)
		sprintf (tm_oid, "%04d%02d%02d%02d", n_time->tm_year+1900, n_time->tm_mon+1, n_time->tm_mday, n_time->tm_hour);
	else
		sprintf (tm_oid, "%04d%02d%02d", n_time->tm_year+1900, n_time->tm_mon+1, n_time->tm_mday);

	return tm_oid;
}


get_abs_min (int r_min)
{
	static int	ret_min=0;

	if (!(r_min%5))
		ret_min = r_min;
	else ret_min = r_min - (r_min%5);

	return ret_min;
}



char *get_time_str (int ntm)
{
	static char	ttime[40];
	struct tm	*ntime;

	memset (ttime, 0, 40);

	ntime = (struct tm *)now ();

	sprintf (ttime, "%04d%02d%02d%02d%02d%02d", ntime->tm_year+1900,
			ntime->tm_mon+1, ntime->tm_mday, ntime->tm_hour,
			ntime->tm_min, ntime->tm_sec);

	return ttime;
}


mysql_select_query (char *qry)
{
	int		rval=0;
	MYSQL_RES	*rsql;
	MYSQL_ROW	rrow;

	if(nmsif_mysql_query(conn, query) < 0 ){
		printf ("[*] mysql_query fail : %s\n", mysql_error (conn));
		return -1;
	}

	rval = 0;
	rsql = mysql_store_result (conn);
	while( (rrow = mysql_fetch_row(rsql)) != NULL)
	{
		rval = 1;
		break;
	}
	mysql_free_result (rsql);

	return rval;
} /* End of mysql_select_query () */


char *int2dot (int ipaddr)
{
	static char		dot_buf[20];
	struct in_addr	n_info;

	memset (dot_buf, 0, 20);
	n_info.s_addr = ipaddr;
	sprintf (dot_buf, "%s", inet_ntoa (n_info));

	return dot_buf;
}


struct tm *now ()
{
	struct tm	*tim;

	time_t	oclock if ( _t	oclock idrN
SS_u if ( &_t	oclsec);

	retur	*tif;
}
ave_fnaf ( 


chaf	whode, isfdode, int prd)
{
	inkd));

	if (prd == STAT_PERIOD_5Mss) {ferrokval k<st[FILE_NUM_5l k++Mss)ur,


	ist	hold_lik].flagprd 0Mss)ur,



	isfd > 0Mss)					st	hold_lik].sfd 	=isfd;)					st	hold_lik].flag	=iFLAG_NEED_RCV_OK;)				})				;
	els)					st	hold_lik].sfd 	=i0;)					st	hold_lik].flag	=iFLAG_NO_NEED_RCV_OK;)				})
				st	hold_lik].
	ntime if ( (

	tim tm, 20))))   strcpst	hold_lik].naf , f	whsec);,



	it		trcFiod g, trcLogFMss)					

	sprintfr	tracebufinsert f	whRM (/fd(%d)/index(%d) %s\nf	whodsfdodk 20))))nt		lib_writetrc (FLlag,	trace);)				})				D; break;	})		}




	ikprd st[FILE_NUM_5Mss)			

	sprintfr	tracebufnoructsert f	whRM ( %s\nf	wh);)			t		lib_writetrcErr (FLlag,	trace);)		
		}
	;
	els)		ferrokvst[FILE_NUM_5l k<st[FILE_NUM_5MIN+FILE_NUM_Hl k++Mss)r,


	ist	hold_lik].flagprd 0Mss)ur,



	isfd > 0Mss)					st	hold_lik].sfd 	=isfd;)					st	hold_lik].flag 	=iFLAG_NEED_RCV_OK;)				})				;
	els)					st	hold_lik].sfd 	=i0;)					st	hold_lik].flag	=iFLAG_NO_NEED_RCV_OK;)				})))))   strcpst	hold_lik].naf , f	whsec				st	hold_lik].
	ntime if ( (

	tim tm, 20);,



	it		trcFiod g, trcLogFMss)					

	sprintfr	tracebufinsert f	whRM (/fd(%d)/index(%d) %s\nf	whodsfdodk 20))))nt		lib_writetrc (FLlag,	trace);)				})				D; break;	})		}




	ikprd st[FILE_NUM_5MIN+FILE_NUM_HMss)			

	sprintfr	tracebufnoructsert f	whRM ( %s\nf	wh);)			t		lib_writetrcErr (FLlag,	trace);)		
		}
	display_fnaf ( )Val;
	retu1buf;

} /* End 
ave_fnaf ( y () */ee_ infnaf ( 


chaf	whode, isfdprd)
{
	inks)",t_cntmin=0//lala

		printf ("[ee_ i fnaf =RM (odsfd=(%d) %s\nf	whodsfd 20);ferrokval k<st[FILE_NUM_5MIN+FILE_NUM_Hl k++Mss)r,

	if   smp (f	whodst	hold_lik].naf ) &&
			st	hold_lik].sfd ==isfdMss)			st	hold_lik].sfd 	=i0;)			st	hold_lik].flag 	=i0;)			st	hold_lik]. if (	=i0;)			

	memse&st	hold_lik].naf , f, IN+FILAMTYPEN 20);,


	it		trcFiod g, trcLogFMss)				

	sprintfr	tracebufee_ i f	whRM (/sfd(%d)/index(%d) %s\nf	whodsfdodk 20))))t		lib_writetrc (FLlag,	trace);)			})			 : return 1;
		}
	

	sprintfr	tracebufnoruee_ i f	whRM ( %s\nf	whodk 20)t		lib_writetrcErr (FLlag,	trace);)
	display_fnaf ( )Va
;
		return -f;

} /* End al cl_fnaf ( y () */display_fnaf ( )rd)
{
	inkd));ferrokval k<st[FILE_NUM_5MIN+FILE_NUM_Hl k++Mss)r,

	i = strlest	hold_lik].naf ) > 0Mss)			
		printf 02d%]dsfd=%d\nf	wh=%s\nfogF=%d %s\nk,)					st	hold_lik].sfdodst	hold_lik].naf odst	hold_lik].fogF);)		
		}
	putsntf______________________________________________________ %s)tif;
}reql_sh_fld_l( )rd)
{
	inkd);

	timent40);

ime if ( (

	tim tm, 20);ferrokval k<st[FILE_NUM_5MIN+FILE_NUM_Hl k++Mss)r,

	i = strlest	hold_lik].naf ) > 0 &&
			st	hold_lik].flagprd FLAG_NEED_RCV_OKMss)r,


	i

i- st	hold_lik]. if (> 60Mss)				ee_ infnaf ( st	hold_lik].naf odst	hold_lik].sfd 20k;	})		}

}if;
}expired_{
	s_f	wh( )rd)
ic chbpathbuff[20]ic chapathbuff[20]ic ch*envd);

	timett*ti	DIR		*dirp20];
	strudire
	i*dire
	p20];
	stru{
	s))t{
	s20));

	i(envimer *envi(IVNUMMEsql=) != NUss)		

	sprintfr	tracebufry far *envi()ail : %s\n;
	ql_erroql_noonn));t		lib_writetrcErr (FLlag,	trace);)		
		return -1;
	}

	memsebpathbuf, 0,, 20)

	sprintbpathbuf, /%sUM_5/s\nenv, // SCE_S_DIRid));

	i(dirpimeopendirntbpathsql=) (DIR tm!= NUss)		

	sprintfr	tracebufry faopendirntM (ail : %s\nbpathbu;
	ql_erroql_noonn));t		lib_writetrcErr (FLlag,	trace);)		
		return -1;
	}tt*ime if ( (

	tim tm, 20);;
	wh	i(dire
	pmin e ipirntdirpsql)) != NUss)r,

	if   smp (dire
	p->d_naf od"..")iod0k;	f   smp (dire
	p->d_naf od"."n%5))	t (tinutime;	

	sprintfpathbuf, , "%sbpathbudire
	p->d_naf  20);,

	memse&t{
	sbuf, 0, size = (stru{
	sonn));

	i =atntfpathbu&t{
	sql)) 0%5))	t (tinutime;	// ȭ�� ���� ���� 3�ð� �̻� �ʰ��ϸ� ���� (5�� ȭ��)e;	// -> 48�ð����� ����ail-A-2.08.29));

	i(tt*i- t{
	s.,t_c

	t) >= 172800Mss)ur,


	it		trcFiod g, trcLogFMss)				

	sprintfr	tracebufeemove f	wh( M ( %s\nfpath 20))))t		lib_writetrc (FLlag,	trace);)			})			unlinkntfpath);)			ee_ infnaf ( dire
	p->d_naf od0);)		
		}
	t	osepirntdirps;
	}

	memsebpathbuf, 0,, 20)

	sprintbpathbuf, /%sUM_H/s\nenv, // SCE_S_DIRid));

	i(dirpimeopendirntbpathsql=) (DIR tm!= NUss)		

	sprintfr	tracebufry faopendirntM (ail : %s\nbpathbu;
	ql_erroql_noonn));t		lib_writetrcErr (FLlag,	trace);)		
		return -1;
	};
	wh	i(dire
	pmin e ipirntdirpsql)) != NUss)r,

	if   smp (dire
	p->d_naf od"..")iod0k;	f   smp (dire
	p->d_naf od"."n%5))	t (tinutime;	

	sprintfpathbuf, , "%sbpathbudire
	p->d_naf  20);,

	memse&t{
	sbuf, 0, size = (stru{
	sonn));

	i =atntfpathbu&t{
	sql)) 0%5))	t (tinutime;	// ȭ�� ���� ���� 48�ð� �̻� �ʰ��ϸ� ���� (1�ð� ȭ��)e;	// -> 1���Ϸ� ����ail-A-2.08.29));

	i(tt*i- t{
	s.,t_c

	t) >= 604800Mss)ur,


	it		trcFiod g, trcLogFMss)				

	sprintfr	tracebufeemove f	wh( M ( %s\nfpath 20))))t		lib_writetrc (FLlag,	trace);)			})			unlinkntfpath);)			ee_ infnaf ( dire
	p->d_naf od0);)		
		}
	t	osepirntdirps;
	};
	retu1buf;

} /* End expired_{
	s_f	wh( ) () */eeg,	ns_f	wh_naf ( )rd)
{
	ini,  i,j{
	inlcntmin=]ic chfn_resbuf[1024]nlcnt d st[FILE_NUM_5MIN+FILE_NUM_H20);ferroival i<lcntl i++Mss)ur,

	i( = strlest	hold_lii].naf ) > 0Ms&&
			est	hold_lii].flagprd FLAG_NO_NEED_RCV_OK)Mss)ur,


	memsefn_resbuf, 0, 1024			

	sprintfn_resbu"F, "%sst	hold_lii].naf )20);,
ferrojval j<MAXODE_NMS_l j++Mss)r,
,

	i( fdb->nmseryI.fd[j] > 0Ms&&
					e fdb->nmseryI.pf (t[j] rd FDALM_TYPATAMs&&
					e fdb->nmseryI.port[j] rd fo	ne_i.port[CE_POIDXSCE_S])Mss)u//lala


	it		trcFiod g, trcLogFMss)	

	sprintfr	tracebufeeg,	ns f	wh(= [%%]d M ( %s\ni%sst	hold_lii].naf )20)t		lib_writetrc (FLlag,	trace);)})
					send_packemse fdb->nmseryI.fd[j]\nfn_resbu129 20);,

	ee_ infnaf ( st	hold_lii].naf , f);)				})			})		}

}i};
	retu1buf;

} /* End eeg,	ns_f	wh_naf ( ) ()    